VEXOGPT branding pack
- VEXOGPT_Logo.png: main logo artwork
- VEXOGPT_App_Icon.png: square app icon preview
- VEXOGPT_Promo.png: promotional app mockup / external image

Android launcher icon resources are installed in app/src/main/res/mipmap-* and the app label is VEXOGPT.
Important: this is the branded source project, not a verified release APK. Configure a valid GPT_API_KEY in secrets.properties (do not publish it) and build/test the app before distributing. API provider access and current project dependencies may need updates.
