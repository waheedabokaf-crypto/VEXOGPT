package com.vexo.vexogpt

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1B1D25)
private val Accent = Color(0xFF9B7BFF)
private val TextMain = Color(0xFFF4F2FA)
private val TextMuted = Color(0xFFAAA7B8)

data class ChatMessage(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VexoApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VexoApp() {
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var input by remember { mutableStateOf("") }
    var serverUrl by remember { mutableStateOf("http://10.0.2.2:3000") }
    var showSettings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel,
            onBackground = TextMain,
            onSurface = TextMain
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("VEXOGPT", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
                    Text("مساعدك الذكي", fontSize = 12.sp, color = TextMuted)
                }
                IconButton(onClick = {
                    messages = emptyList()
                    error = ""
                }) {
                    Icon(Icons.Default.Add, contentDescription = "محادثة جديدة", tint = TextMain)
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "الإعدادات", tint = TextMain)
                }
            }
            HorizontalDivider(color = Color(0xFF2A2C36))

            if (messages.isEmpty()) {
                Column(
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier.size(76.dp).background(Accent.copy(alpha = .16f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("V", color = Accent, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.height(22.dp))
                    Text("أهلًا بك في VEXOGPT", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = TextMain)
                    Spacer(Modifier.height(8.dp))
                    Text("اسأل، تعلّم، اكتب، أو اطلب المساعدة في أي فكرة.", color = TextMuted, fontSize = 14.sp)
                    Spacer(Modifier.height(22.dp))
                    Suggestion("اشرح لي فكرة بطريقة بسيطة") { input = "اشرح لي فكرة بطريقة بسيطة" }
                    Spacer(Modifier.height(8.dp))
                    Suggestion("ساعدني في كتابة كود") { input = "ساعدني في كتابة كود" }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
                    contentPadding = PaddingValues(vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    itemsIndexed(messages) { _, message ->
                        MessageBubble(message)
                    }
                    if (busy) item {
                        Text("VEXOGPT يكتب الآن…", color = Accent, modifier = Modifier.padding(8.dp))
                    }
                }
                LaunchedEffect(messages.size, busy) {
                    if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
                }
            }

            if (error.isNotBlank()) {
                Text(error, color = Color(0xFFFF8A8A), fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)
                    .background(Panel, RoundedCornerShape(24.dp)).padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(vertical = 9.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 15.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(Accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        sendMessage(input, serverUrl, messages, busy, { messages = it }, { busy = it }, { error = it }, { input = it }, scope)
                    }),
                    decorationBox = { inner ->
                        Box {
                            if (input.isEmpty()) Text("اكتب رسالتك هنا...", color = TextMuted, fontSize = 14.sp)
                            inner()
                        }
                    }
                )
                Spacer(Modifier.width(8.dp))
                IconButton(
                    enabled = input.isNotBlank() && !busy,
                    onClick = {
                        sendMessage(input, serverUrl, messages, busy, { messages = it }, { busy = it }, { error = it }, { input = it }, scope)
                    },
                    modifier = Modifier.size(44.dp).background(if (input.isNotBlank() && !busy) Accent else Color(0xFF45414F), CircleShape)
                ) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = "إرسال", tint = Color.White)
                }
            }
            Text("قد تكون إجابات الذكاء الاصطناعي غير دقيقة.", color = TextMuted, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                containerColor = Panel,
                title = { Text("إعدادات الاتصال", color = TextMain) },
                text = {
                    Column {
                        Text("عنوان الخادم (Backend URL)", color = TextMuted, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = serverUrl,
                            onValueChange = { serverUrl = it.trimEnd('/') },
                            singleLine = true,
                            placeholder = { Text("https://your-server.example") }
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("للمحاكي: http://10.0.2.2:3000 — للهاتف الحقيقي استخدم عنوان الكمبيوتر المحلي أو رابط HTTPS.", color = TextMuted, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSettings = false }) { Text("حفظ", color = Accent) }
                }
            )
        }
    }
}

@Composable
private fun Suggestion(text: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)) {
        Text(text, fontSize = 13.sp)
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val user = message.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (user) Arrangement.Start else Arrangement.End
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(.91f)
                .background(if (user) Color(0xFF272331) else Panel, RoundedCornerShape(18.dp))
                .padding(14.dp)
        ) {
            Text(if (user) "أنت" else "VEXOGPT", color = if (user) Accent else Color(0xFFB8A5FF),
                fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(message.text, color = TextMain, fontSize = 15.sp, lineHeight = 23.sp)
        }
    }
}

private fun sendMessage(
    raw: String,
    baseUrl: String,
    current: List<ChatMessage>,
    isBusy: Boolean,
    setMessages: (List<ChatMessage>) -> Unit,
    setBusy: (Boolean) -> Unit,
    setError: (String) -> Unit,
    clearInput: (String) -> Unit,
    scope: kotlinx.coroutines.CoroutineScope
) {
    val text = raw.trim()
    if (text.isEmpty() || isBusy) return
    val updated = current + ChatMessage("user", text)
    setMessages(updated)
    clearInput("")
    setBusy(true)
    setError("")
    scope.launch {
        try {
            val reply = withContext(Dispatchers.IO) { requestAssistant(baseUrl, updated) }
            setMessages(updated + ChatMessage("assistant", reply))
        } catch (e: Exception) {
            setError("تعذّر الاتصال بالخادم: ${e.message ?: "خطأ غير معروف"}")
        } finally {
            setBusy(false)
        }
    }
}

private fun requestAssistant(baseUrl: String, messages: List<ChatMessage>): String {
    val url = URL(baseUrl.trimEnd('/') + "/chat")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 90000
        doOutput = true
        setRequestProperty("Content-Type", "application/json; charset=utf-8")
    }
    try {
        val history = JSONArray()
        messages.takeLast(30).forEach {
            history.put(JSONObject().put("role", it.role).put("content", it.text))
        }
        val body = JSONObject().put("messages", history).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        if (code !in 200..299) {
            val detail = try { JSONObject(response).optString("error", response) } catch (_: Exception) { response }
            throw IllegalStateException("HTTP $code: $detail")
        }
        return JSONObject(response).optString("reply").ifBlank { "وصل رد فارغ من الخادم." }
    } finally {
        connection.disconnect()
    }
}
