import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const port = Number(process.env.PORT || 3000);
const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || 'gpt-4.1-mini';

app.get('/health', (_req, res) => res.json({ ok: true, app: 'VEXOGPT backend' }));

app.post('/chat', async (req, res) => {
  try {
    if (!apiKey) {
      return res.status(503).json({ error: 'لم يتم ضبط OPENAI_API_KEY على الخادم.' });
    }
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'أرسل مصفوفة messages غير فارغة.' });
    }

    const safeMessages = messages.slice(-30).map((m) => {
      const role = m?.role === 'assistant' ? 'assistant' : 'user';
      const content = String(m?.content ?? '').slice(0, 12000);
      return { role, content };
    });

    const client = new OpenAI({ apiKey });
    const response = await client.responses.create({
      model,
      instructions: 'أنت VEXOGPT، مساعد ذكي مفيد وواضح. أجب بلغة المستخدم، واستخدم العربية عندما يكتب بالعربية.',
      input: safeMessages
    });

    res.json({ reply: response.output_text || 'لم أتمكن من إنشاء إجابة نصية.' });
  } catch (error) {
    console.error('VEXOGPT request failed:', error?.status || '', error?.message || error);
    res.status(500).json({ error: 'حدث خطأ أثناء طلب الإجابة. تحقق من إعدادات النموذج ومفتاح API وسجل الخادم.' });
  }
});

app.listen(port, '0.0.0.0', () => {
  console.log(`VEXOGPT backend listening on port ${port}; model=${model}`);
});
